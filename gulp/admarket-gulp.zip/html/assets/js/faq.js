$(document).ready(function(){
	$("#sec_faq dt").on("click", function() {
		$(this).next().stop(true,true).slideToggle();
		$(this).toggleClass("active");
	});
	$('#faq01').css({"display":"block"});
	$('#faq02').css({"display":"none"});
		
	$("#tab01").click(function(){
		$('#sec_faq > div').css({"display":"none"});
		$('#faq01').fadeIn();
		$('#tab01').addClass("active");
		$('#tab02').removeClass("active");
	});
	$("#tab02").click(function(){
		$('#sec_faq > div').css({"display":"none"});
		$('#faq02').fadeIn();
		$('#tab01').removeClass("active");
		$('#tab02').addClass("active");
	});
	
});