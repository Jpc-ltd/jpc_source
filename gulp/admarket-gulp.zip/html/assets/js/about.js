$(function(){
  function sliderSetting(){

    var width = $(window).width();

    if(width <= 480){
      $('.follow-row').not('.slick-initialized').slick({
        centerMode: true,
        slidesToShow: 1,
        centerPadding:'14%',
        variableWidth: false,
      });
    } else {
      $('.slide.slick-initialized').slick('unslick');
    }
  }

  sliderSetting();

  $(window).resize( function() {
    sliderSetting();
  });
});