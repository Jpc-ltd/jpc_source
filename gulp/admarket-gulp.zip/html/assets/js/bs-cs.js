var agent = navigator.userAgent;
if(agent.search(/iPhone/) != -1 || agent.search(/iPad/) != -1 || agent.search(/iPod/) != -1 || agent.search(/Android/) != -1){
    document.write('<link href="/lp6/css/ua.css" rel="stylesheet">');
}

$(function(){
  var timer = false;
  $(window).on('load resize', function() {

      if (timer !== false) {
          clearTimeout(timer);
      }
      timer = setTimeout(function() {
        var winWidth = window.innerWidth;

		if( winWidth <= 768 ){
			// 画像置換（PC→SP）
			$('.rwd').each(function(){
				$(this).attr("src",$(this).data("img").replace('_pc', '_sp'));
			});
		}else {
			// 画像置換（SP→PC）
			$('.rwd').each(function(){
				$(this).attr("src",$(this).data("img"));
			});
		}
      }, 10);
  });
  $(window).trigger('resize');
});