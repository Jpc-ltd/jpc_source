/*----------------------------------------------------
 hamburger-menu
-----------------------------------------------------*/
$(function () {


 $('.hamburger').on('click', function () {
  var winWidth = window.innerWidth;
  if (winWidth < 481) {
   if ($('.hamburger').is('.open')) {
    $('.sp-header').stop(true, true).fadeOut();
    $(this).removeClass('open');
    $('header').removeClass('ham-header');
    $('body,html').css({
     "overflow": "visible",
     "height": "auto"
    });
   } else {
    $('.sp-header').stop(true, true).fadeIn().css('display', 'block');
    $(this).addClass('open');
    $('header').addClass('ham-header');
    $('body,html').css({
     "overflow": "hidden",
     "height": "100%"
    });
   }
  }
 });

 $('.gnav__link--open').on('click', function (e) {
  var winWidth = window.innerWidth;
  if (winWidth < 481) {
   e.preventDefault();
   $(this).parent().find('.gnav-child').stop(true, true).slideToggle();
   $(this).toggleClass('open');
   $(this).parent().toggleClass('slide');
  }
 });
});

/*----------------------------------------------------
 Load / Resize Event
-----------------------------------------------------*/
$(function () {
 var timer = false;
 $(window).on('load resize', function () {

  if (timer !== false) {
   clearTimeout(timer);
  }
  timer = setTimeout(function () {
   var winWidth = window.innerWidth;

   if (winWidth <= 480) {
    // 画像置換（PC→SP）
    $('.rwd').each(function () {
     $(this).attr("src", $(this).data("img").replace('_pc', '_sp'));
    });
   } else {
    // 画像置換（SP→PC）
    $('.rwd').each(function () {
     $(this).attr("src", $(this).data("img"));
    });
   }
  }, 10);
 });
 $(window).trigger('resize');
});

/*----------------------------------------------------
 スムーススクロール
-----------------------------------------------------*/
$(function () {
 $('a[href^=#]:not(.close-btn a)').click(function () {
  var speed = 1000;
  var href = $(this).attr("href");
  var target = $(href == "#" || href == "" ? 'html' : href);
  var position = target.offset().top - 140;
  var SPposition = target.offset().top - 70;
  var winWidth = $(window).width();
  if (winWidth >= 480) {
   $('html, body').animate({
    scrollTop: position
   }, speed, 'easeOutCubic');
  } else {
   $('html, body').animate({
    scrollTop: SPposition
   }, speed, 'easeOutCubic');
  }
  return false;
 });
});

/*-----------------------------
	Page Top Button
	------------------------------*/
$(window).on("load scroll resize", function () {
 if ($(window).scrollTop() > 100) {
  $("#pagetop").addClass("show");
 } else {
  $("#pagetop").removeClass("show");
 }

 if ($(window).scrollTop() > ($("body").outerHeight() - $(window).height() - 600)) {
  $(".scroll").addClass("fade");
  $("#pagetop").addClass("bottom");
 } else {
  $("#pagetop").removeClass("bottom");
  $(".scroll").removeClass("fade");
 }
});




$(function () {

 $('.content-box').css('cursor', 'pointer');
 $('.content-box').on('click', function () {

  $(this).find("a")[0].click();

 });
});

$(function () {

 $('.contact-btn').css('cursor', 'pointer');
 $('.contact-btn').on('click', function () {

  $(this).find("a")[0].click();

 });
});

$(function () {

 $('.service-box').css('cursor', 'pointer');
 $('.service-box').on('click', function () {

  $(this).find("a")[0].click();

 });
});

function sctop() {
 $(function () {
  var speed = 500;
  $("html, body").animate({
   scrollTop: 0
  }, speed, "swing");
 });
}

/*-----------------------------
右サイドナビゲーション
------------------------------*/

$(window).on("load scroll resize", function () {
 if ($(window).scrollTop() > 700) {
  $(".side-nav").addClass("show");
 } else {
  $(".side-nav").removeClass("show");
 }
});

$(window).load(function() {
 
    // ナビゲーションのリンクを指定
   var navLink = $('.side-nav li a');
 
    // 各コンテンツのページ上部からの開始位置と終了位置を配列に格納しておく
   var contentsArr = new Array();
  for (var i = 0; i < navLink.length; i++) {
       // コンテンツのIDを取得
      var targetContents = navLink.eq(i).attr('href');
      // ページ内リンクでないナビゲーションが含まれている場合は除外する
      if(targetContents.charAt(0) == '#') {
         // ページ上部からコンテンツの開始位置までの距離を取得
            var targetContentsTop = $(targetContents).offset().top - 400;
         // ページ上部からコンテンツの終了位置までの距離を取得
            var targetContentsBottom = targetContentsTop + $(targetContents).outerHeight(true);
         // 配列に格納
            contentsArr[i] = [targetContentsTop, targetContentsBottom]
       console.log(targetContentsTop);
      }
   };
   
 
  // 現在地をチェックする
   function currentCheck() {
       // 現在のスクロール位置を取得
        var windowScrolltop = $(window).scrollTop();
        for (var i = 0; i < contentsArr.length; i++) {
           // 現在のスクロール位置が、配列に格納した開始位置と終了位置の間にあるものを調べる
          if(contentsArr[i][0] <= windowScrolltop && contentsArr[i][1] >= windowScrolltop) {
                // 開始位置と終了位置の間にある場合、ナビゲーションにclass="current"をつける
               navLink.removeClass('cr');
               navLink.eq(i).addClass('cr');
                i == contentsArr.length;
            }
       };
  }
 
   // ページ読み込み時とスクロール時に、現在地をチェックする
  $(window).on('load scroll', function() {
      currentCheck();
 });
 
});
$(window).scroll(function(){
    var sc = $(this).scrollTop();
    console.log(sc);
});