var breakPoint = 767;
var timer = false;

//----------------------------------------------------
//  画像置換
//----------------------------------------------------
$(function(){
  $(window).on('load resize', function() {

    if (timer !== false) {
      clearTimeout(timer);
    }
    timer = setTimeout(function() {
      var winWidth = window.innerWidth;

      if( winWidth <= breakPoint ){
        // 画像置換（PC→SP）
        $('.rwd').each(function(){
          $(this).attr("src",$(this).data("img").replace('_pc', '_sp'));
        });
      }else {
        // 画像置換（SP→PC）
        $('.rwd').each(function(){
          $(this).attr("src",$(this).data("img"));
        });
      }
    }, 10);
  });
  $(window).trigger('resize');
});


//----------------------------------------------------
//  アニメーション
//----------------------------------------------------
$(window).on('scroll load', function(){
  $('.js-fadeup-row').each( function(){
    $(this).children('.js-fadeup-row-child').each(function(i){
      $(this).css({
        'transition-delay' : (i * .8) + 's'
      });
    });
  });

  $('.js-fadeup, .js-fadeup-row').each(function(){
    var elemPos = $(this).offset().top;
    var scroll = $(window).scrollTop();
    var windowHeight = $(window).height();
    if (scroll > elemPos - windowHeight + 300){
      $(this).addClass('is-visible');
    }
  });
});


//----------------------------------------------------
//  tel
//----------------------------------------------------
$(function(){
  var ua = navigator.userAgent;
  if (ua.indexOf('iPhone') > 0 || ua.indexOf('Android') > 0 && ua.indexOf('Mobile') > 0) {
    // smartphone
  } else if (ua.indexOf('iPad') > 0 || ua.indexOf('Android') > 0) {
    // tablet
  } else {
    // PC
    $('a[href^=tel]').css({
      'cursor' : 'default',
      'pointer-events' : 'none'
    });
    $('a[href^=tel]').click(function(){
      return false;
    });
  }
});


//----------------------------------------------------
//  PAGE TOP
//----------------------------------------------------
$(function(){
  btn = $('.page-top');

  $(btn).hide();

  $(window).on('scroll', function() {
    if ($(this).scrollTop() > 100) {
      $(btn).fadeIn(300);
    } else {
      $(btn).fadeOut(300);
    }

    // 指定位置で止めたい場合
    var scrollPosition = $(window).height() + $(window).scrollTop(); //現在地
    var stopPosition = $('.l-footer').offset().top; //止めたい位置

    if ( scrollPosition >= stopPosition ) {
      btn.addClass('is-absolute');
    } else {
      btn.removeClass('is-absolute');
    }
  });
});


//----------------------------------------------------
//  スムーススクロール
//----------------------------------------------------
$(function () {
  var headerHeight = $('.l-header').outerHeight(); //fixedのヘッダーの高さを取得
  $('a[href^="#"]').on('click',function(){
    var href= $(this).attr("href");
    var target = $(href == "#" || href == "" ? 'html' : href);
    var position = target.offset().top - headerHeight;
    $('body,html').stop().animate({scrollTop:position}, 500);
    return false;
  });
});
