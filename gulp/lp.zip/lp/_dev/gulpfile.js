'use strict'
var gulp = require('gulp');
var sass = require('gulp-sass');
var sassGlob = require('gulp-sass-glob');
var rename = require("gulp-rename");
var autoprefixer = require("gulp-autoprefixer");
var postcss = require('gulp-postcss');
var mqpacker = require('css-mqpacker');
var browsersync = require("browser-sync").create();
var connectSSI   = require('connect-ssi');

// サーバーを立ち上げる
gulp.task('build-server', function (done) {
  browsersync.init({
    server: {
      baseDir: '../', // 出力先のフォルダパス
      middleware: [
        connectSSI({
          baseDir: '../',
          ext: '.html'
        })
      ]
    }
  });
  done();
  console.log('Server was launched');
});

// 監視ファイル
gulp.task('watch-files', function(done) {
  gulp.watch(['../**/*.html','../**/*.css'], gulp.task('browser-reload'));
  gulp.watch(['../assets/**/*.scss','!../_dev/node_modules/**/*.scss'], gulp.series('sass-compile'));
  done();
  console.log(('gulp watch started'));
});

// ブラウザのリロード
gulp.task('browser-reload', function (done){
    browsersync.reload();
    done();
    console.log('Browser reload completed');
});


//for Direcroty
var sassDir = {
  css: 'css',
  scss: 'sass',
  dir: ''
};
// scss用のコンパイル作業
gulp.task('sass-compile', function(done){
    gulp.src(['../assets/**/*.scss', '!../_dev/node_modules/**/*.scss'], { base: '../' }) // scssがあるパスを指定
      .pipe(sassGlob()) // scss importを*で読込めるようにする
      .pipe(sass({ // scssコンパイル実行
        // outputStyle: 'expanded' // 書き出し種類
        outputStyle: 'compressed'
      }).on('error', sass.logError)) // scssのコンパイルエラーを表示
      .pipe(postcss([mqpacker()])) // @mediaをまとめる
      .pipe(autoprefixer()) // package.jsonに記述
      .pipe(rename(function (path) { // リネーム
        path.dirname = path.dirname.replace( sassDir.scss, sassDir.css); // sass→cssに
      }))
      .pipe(gulp.dest('../')); // 書き出し先
    done();
});

// タスクの実行
gulp.task('default', gulp.series('build-server', 'watch-files', 'sass-compile', function(done){
    done();
    console.log('Default all task done!');
}));
